/*******************************************************************************

Beispielprogramm zur Ansteuerung des DOGM128 Displays von Electronic Assembly.
Es wird das Universal Serial Interface A1 im SPI-Mode genutzt. Auf das Display
wird nur geschrieben. Es wird immer das ganze Bild geschrieben. Die �bertragung
erfolgt inBl�cken zu je 128 Byte. Dazwischen wird immer die neue Zeile
eingestellt.

Autor:          Michael Petzold
Datum:          10.03.2009
Lizenz:         Creative Commons Attribution-ShareAlike 3.0 Unported
                http://creativecommons.org/licenses/by-sa/3.0/legalcode


Prozessor:      MSP430F2618

*******************************************************************************/

/**************** Includes ****************************************************/
#include <io.h>

#include "glcd.h"
#include "bilder.h"

/**************** Variablen ***************************************************/
char GRam[1024];                   //Bildspeicher

/**************** Funktionsprototypen *****************************************/
void clock_init(void);
void delay_10us(unsigned int usec);
void delay_ms(unsigned int ms);

/**************** Hauptprogramm ***********************************************/
int main( void )
{
  //Taktquellen initialisieren
  clock_init();

  //Schnittstelle SPI_1A initialisieren
  SPI_A1_init();

  //Interrrupts einschalten
  _BIS_SR(GIE);

  //Initialisierung des Grafik Displays
  GLCD_INIT();

  //Hintergrundbeleuchtung einschalten
  GLCD_HBEL(on);

  //Startbildschirm ausgeben
  Send_Bild((char*)bild);

  //Hauptschleife
  while(1)
  {
  }
}

/**************** Initialisierung der MCU - Taktquellen ***********************/
// Funktion Taktinitialisierung
void clock_init(void)
{
  volatile unsigned int i;              // Zaehlvariable
  WDTCTL = WDTPW + WDTHOLD;             // stoppt den WDT
  BCSCTL1 |= XTS;                       // ACLK=LFXT1=HF Quarz (16Mhz)
  BCSCTL3 |= LFXT1S_2;                  //Bereich in dem der Quarz liegt
  BCSCTL1 |= DIVA_0;    	        // Vorteiler = 1
  do
  {
    IFG1 &= ~OFIFG;                     // l�scht das OSC-FehlerFlag
    for (i = 0xFF; i > 0; i--);         // Einschwingzeit
  }
  while (IFG1 & OFIFG);                 // OSC Fehlerflag wieder gesetzt?
  BCSCTL2 |= SELM_3;                    // MCLK=LFXT1 (Schwingquarz an XT1)
  BCSCTL2 |= DIVM_0;	                // Vorteiler = 1
}
