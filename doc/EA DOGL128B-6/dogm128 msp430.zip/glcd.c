/*******************************************************************************

Hier werden die Routinen zur Ansteuerung des Grafikdisplays DOGM128 von
Electronic Assembly bereitgestellt.

Funktionen:
      - Initialisierung der SPI-Schnittstelle
      - Senden von Daten �ber die SPI-Schnittstelle
      - Senden einer Folge von Steuerzeichen
      - Senden des Grafikspeichers an das Display
      - Einstellen des Kontrastes
      - Ein-/Ausschalten der Hintergrundbeleuchtung
      - Empfangsinterrupt ist rudiment�r vorhanden

Autor:          Michael Petzold
Datum:          10.03.2009
Lizenz:         Creative Commons Attribution-ShareAlike 3.0 Unported
                http://creativecommons.org/licenses/by-sa/3.0/legalcode

Prozessor:      MSP430F2618

*******************************************************************************/

/**************** Includes ****************************************************/
#include <io.h>
#include <signal.h>
#include "glcd.h"

/**************** Variablen ***************************************************/
char rxdaten;

/**************** Initialisierungsarray ***************************************/
// Steuerbefehle zur Initialisierung des Grafik - Displays
const char init[] = {0x40,    //Display start line 0
                     0xa1,    //ADC reverse
                     0xc0,    //Normal COM0...COM63
                     0xa6,    //Display normal
                     0xa2,    //Set Bias 1/9 (Duty 1/65)
                     0x2f,    //Booster, Regulator and Follower On
                     0xf8,    //Set internal Booster to 4x
                     0x00,
                     0x27,    //Contrast set
                     0x81,
                     0x0f,
                     0xac,    //No indicator
                     0x01,
                     0xaf,    //Display on
                     0xb0,    //Page 0 einstellen
                     0x10,    //High-Nible der Spaltenadresse
                     0x00     //Low-Nible der Spaltenadresse
                     };

/**************** Funktionsprototypen *****************************************/
void SPI_A1_init(void);
void Send_Array(char* DATA, char i);
void Send_DMA(char* Data, char i);
void Send_STRG(char* SData, char i);
void Send_DATA(char* Data, char i);
void GLCD_INIT(void);
void Send_Bild(char* data);
void GLCD_HBEL(char i);
void Set_Con(char i);

/**************** Funktionen **************************************************/
//Initialisierung der SPI Schnittstelle
void SPI_A1_init(void)
{
  //SPI - Schnittstelle anhalten
  UCA1CTL1 |= UCSWRST;
  // MOSI und MISO f�r USCI1A an Port 3
  P3SEL |= BIT6 + BIT7;
  // CLK f�r USCI1A an Port 5
  P5SEL |= BIT0;
  // SPI - Modus einstellen
  // 3-pin, 8-bit SPI master
  UCA1CTL0 |= UCSYNC + UCMST + UCCKPL  + UCMSB;
  // Taktquelle einstellen
  UCA1CTL1 |= UCSSEL_1;
  // Teiler f�r den Takt einstellen
  UCA1BR0 = 0x01; // keine Teilung
  UCA1BR1 = 0x00;
  // Schnittstellenhardware einschalten
  UCA1CTL1 &= ~UCSWRST;
  // Empfangsinterrupt einschalten
  UC1IE |= UCA1RXIE;
}

//Sendet ein Array �ber die SPI Schnittstelle
//kein DMA - Transfer
//Parameter
//     DATA:  Daten die gesendet werden sollen
//     i:     Anzahl an Bytes die �bertragen werden sollen
void Send_Array(char* DATA, char i)
{
  while(i)
  {
    while (!(UC1IFG & UCA1TXIFG));  //Sendepuffer bereit?
    UCA1TXBUF = *DATA;              //Steuerungsdaten senden
    DATA++;                         //Pointer auf daten incementieren
    i--;                            //Bytez�hler dekrementieren
  }
  while (!(UC1IFG & UCA1TXIFG));    //Warten das Sendepuffer leer ist
}

//Sendet eine Kette von Steuerzeichen an das Display
//Parameter:
//     SData:   Array mit den Steuerzeichen
//     i:       Anzahl der zu �bertragenden Bytes
void Send_STRG(char* SData, char i)
{
  GLCD_P &= ~(1<<GLCD_CS);            //Chip Select auf 0 legen
  GLCD_P &= ~(1<<GLCD_A0);            //A0 auf 0 legen
  Send_Array(SData, i);               //Daten senden
  GLCD_P |= (1<<GLCD_CS);             //Chip Select wieder auf 1 legen
}

//Sendet eine Kette von Daten an das Display
//Parameter:
//     Data:    Array mit den Daten
//     i:       Anzahl der zu �bertragenden Bytes
void Send_DATA(char* Data, char i)
{
  GLCD_P &= ~(1<<GLCD_CS);            //Chip Select auf 0 legen
  GLCD_P |= (1<<GLCD_A0);             //A0 auf 1 legen
  Send_Array(Data, i);                //Daten senden
  GLCD_P |= (1<<GLCD_CS);             //Chip Select wieder auf 1 legen
  GLCD_P &= ~(1<<GLCD_A0);            //A0 auf 0 legen
}

//Initialisierung des Grafikdisplays
void GLCD_INIT(void)
{
  //Port 7 f�r die Steuerleitungen und das Hintergrundlicht einstellen
  GLCD_S &= ~0x3f;         //Steuerleitungen als I/O einstellen
  GLCD_D |= 0x3f;          //Steuerleitungen als Ausgang einstellen
  GLCD_P &= ~0x3f;         //Alle Steuerleitungen auf 0 setzen
  GLCD_P |= (1<<GLCD_CS);  //Chip Select auf 1 setzen (Ausgangszustand hergestellt)
  Send_STRG((char*)init, 18);
}

//Zeile und Spalte an dem Display einstellen
//Parameter:
//     x:    X - Position im Display (0 - 127)
//     y:    Y - Position im Display (0 - 8)
void goto_xy(char x, char y)
{
  char set[] = {0xb0, 0x10, 0x00};    //Befehlsarray
  set[0] = set[0] + y;                //Y - Position auf Steuerbefehl addieren
  set[2] = set[2] + (x & 0x0f);       //Low - Nibble auf Steuerbefehl addieren
  set[1] = set[1] + (x >> 4);         //High - Nibble auf Steuerbefehl addieren
  Send_STRG(set, 3);
}

//kompletten Bildspeicher an das Display �bertragen
//Parameter:
//     data:  Datenarray, was �bertragen werden soll
void Send_Bild(char* data)
{
  unsigned char z;
  for(z=0; z<8; z++)                    //Zeilenz�hler
  {
    goto_xy(0, z);                      //Anfang der aktuellen Zeile einstellen
    Send_DATA(data + (z*128), 128);     //128Byte senden
  }
}

//Ein-/Ausschalten der Hintergrundbeleuchtung
//Anpassen an die jeweilige Anzahl der vorhandenen Steuertransistoren
void GLCD_HBEL(char i)
{
  if (i)
  {
    GLCD_P |= (1<<GLCD_H1);
  }
  else
  {
    GLCD_P &= ~(1<<GLCD_H1);
  }
}

//Funktion zum Einstellen des Kontrastes am Display
//Parameter:
//     i:    Wert f�r den Kontrast (0 - 63)
void Set_Con(char i)
{
  char set[] = {0x81, 0x00};   //Befehl aus Datenblatt
  if (i>0x3f)                  //auf Grenzen pr�fen
    set[1] = set[1] + 0x3f;    //Max. einstellen
  else
    set[1] = set[1] + i;       //Sonst Wert einstellen
  Send_STRG(set, 2);           //Daten senden
}

/******************** Interruptroutinen **************************************/
// Hier Routine f�r den Empfangsinterrupt einf�gen
interrupt (USCIAB1RX_VECTOR) SPI0_RX_ISR()
{
  rxdaten = UCA1RXBUF;
}

